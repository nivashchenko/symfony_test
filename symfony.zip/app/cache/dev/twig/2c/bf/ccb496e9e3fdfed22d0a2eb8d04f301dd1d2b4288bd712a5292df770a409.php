<?php

/* FakeUserBundle::base.html.twig */
class __TwigTemplate_2cbfccb496e9e3fdfed22d0a2eb8d04f301dd1d2b4288bd712a5292df770a409 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'navigation' => array($this, 'block_navigation'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<!--[if lt IE 7]>      <html class=\"no-js lt-ie9 lt-ie8 lt-ie7\"> <![endif]-->
<!--[if IE 7]>         <html class=\"no-js lt-ie9 lt-ie8\"> <![endif]-->
<!--[if IE 8]>         <html class=\"no-js lt-ie9\"> <![endif]-->
<!--[if gt IE 8]><!--> <html class=\"no-js\"> <!--<![endif]-->
\t<head>
\t\t<meta charset=\"utf-8\">
\t\t<title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
\t\t<meta name=\"description\" content=\"\">
\t\t<meta name=\"author\" content=\"\" />
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

\t\t<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
                
                ";
        // line 15
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 24
        echo "                    <link rel=\"shortcut icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
                    <link rel=\"shortcut icon\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("apple-touch-icon.png"), "html", null, true);
        echo "\" />

\t\t<script>
\t\t\tdocument.cookie='resolution='+Math.max(screen.width,screen.height)+(\"devicePixelRatio\" in window ? \",\"+devicePixelRatio : \",1\")+'; path=/';
\t\t</script><!-- Responsive images -->
\t</head>
\t<body>
\t\t<!--[if lt IE 7]>
\t\t\t<p class=\"chromeframe\">You are using an outdated browser. <a href=\"http://browsehappy.com/\">Upgrade your browser today</a> or <a href=\"http://www.google.com/chromeframe/?redirect=true\">install Google Chrome Frame</a> to better experience this site.</p>
\t\t<![endif]-->

\t\t<!-- Add your site or application content here -->
                ";
        // line 37
        $this->displayBlock('navigation', $context, $blocks);
        // line 63
        echo "                ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "all", array(), "method"));
        foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
            // line 64
            echo "                    ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["key"] => $context["message"]) {
                // line 65
                echo "                        <div class=\"flash-";
                echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                echo "\">
                            ";
                // line 66
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($context["message"], array(), "FOSUserBundle"), "html", null, true);
                echo "
                        </div>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 69
            echo "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "                ";
        $this->displayBlock('body', $context, $blocks);
        // line 72
        echo "                <footer class=\"site-footer site-footer-font\">
\t\t\t<div class=\"sparator\"></div>
\t\t\t<div class=\"contact\">
\t\t\t\t<a href=\"mailto:hexocat.themes@gmail.com\"><i class=\"icon-envelope-alt\"></i> hexocat.themes@gmail.com</a> &middot;
\t\t\t\t<a href=\"tel:4213-45-710\"><i class=\"icon-phone\"></i> 4213-45-710</a> &middot;
\t\t\t\t<a href=\"http://www.twitter.com\"><i class=\"icon-twitter\"></i> @Mori</a> &middot;
\t\t\t\t<a href=\"http://www.facebook.com\"><i class=\"icon-facebook-sign\"></i> /mori.h</a>
\t\t\t</div>
\t\t\t<div class=\"copyright\">Template Copyright &#64; 2012 My Story. Made by <a href=\"#\">Hexocat</a> with <i class=\"icon-heart\"></i></div>
\t\t</footer>

\t\t<script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js\"></script>
\t\t<script>window.jQuery || document.write('<script src=\"js/jquery-1.8.0.min.js\"><\\/script>')</script>
\t\t<script src=\"js/plugins.js\"></script>
\t\t<script src=\"js/main.js\"></script>

\t\t<!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
\t\t<script>
\t\t\tvar _gaq=[['_setAccount','UA-XXXXX-X'],['_trackPageview']];
\t\t\t(function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
\t\t\tg.src=('https:'==location.protocol?'//ssl':'//www')+'.google-analytics.com/ga.js';
\t\t\ts.parentNode.insertBefore(g,s)}(document,'script'));
\t\t</script>
\t</body>
</html>
";
    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        echo "Fake Apps";
    }

    // line 15
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 16
        echo "                    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/normalize.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
                    <link href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/font-face.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
                    <link href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/color-schemes/dark/hot-pink.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
                    <link href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/typography.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
                    <link href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/font-awesome.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
                    <link href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
                    <link href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" />
                ";
    }

    // line 37
    public function block_navigation($context, array $blocks = array())
    {
        // line 38
        echo "                    <nav>
                            <div class=\"top-ribbon\"></div>
                            <ul class=\"nav-font clearfix\">
                                    <li>
                                        ";
        // line 42
        if ($this->env->getExtension('security')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 43
            echo "                                        ";
        } else {
            // line 44
            echo "                                            <a href=\"";
            echo $this->env->getExtension('routing')->getPath("fos_user_registration_register");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.register", array(), "FOSUserBundle"), "html", null, true);
            echo "</a>
                                        ";
        }
        // line 46
        echo "                                    </li>
                                    <li>
                                        ";
        // line 48
        if ($this->env->getExtension('security')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 49
            echo "                                            ";
            // line 50
            echo "                                            <a href=\"";
            echo $this->env->getExtension('routing')->getPath("fos_user_security_logout");
            echo "\">
                                                ";
            // line 51
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "
                                            </a>
                                        ";
        } else {
            // line 54
            echo "                                            <a href=\"";
            echo $this->env->getExtension('routing')->getPath("fos_user_security_login");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.login", array(), "FOSUserBundle"), "html", null, true);
            echo "</a>
                                        ";
        }
        // line 56
        echo "                                    </li>
                                    <li>
                                        <a href=\"";
        // line 58
        echo $this->env->getExtension('routing')->getPath("fake_template_homepage");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("template.home_page", array(), "FakeUserBundle"), "html", null, true);
        echo "</a>
                                    </li>
                            </ul>
                    </nav>
                ";
    }

    // line 70
    public function block_body($context, array $blocks = array())
    {
        // line 71
        echo "                ";
    }

    public function getTemplateName()
    {
        return "FakeUserBundle::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  235 => 71,  232 => 70,  221 => 58,  217 => 56,  209 => 54,  203 => 51,  198 => 50,  196 => 49,  194 => 48,  190 => 46,  182 => 44,  179 => 43,  177 => 42,  171 => 38,  168 => 37,  162 => 22,  158 => 21,  154 => 20,  150 => 19,  146 => 18,  142 => 17,  137 => 16,  134 => 15,  128 => 8,  99 => 72,  96 => 70,  90 => 69,  81 => 66,  76 => 65,  71 => 64,  66 => 63,  64 => 37,  49 => 25,  44 => 24,  42 => 15,  32 => 8,  23 => 1,);
    }
}

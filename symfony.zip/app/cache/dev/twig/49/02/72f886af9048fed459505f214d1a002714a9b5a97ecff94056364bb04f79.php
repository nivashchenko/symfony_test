<?php

/* FakeTemplateBundle:Default:template.html.twig */
class __TwigTemplate_490272f886af9048fed459505f214d1a002714a9b5a97ecff94056364bb04f79 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        try {
            $this->parent = $this->env->loadTemplate("FakeUserBundle::layout.html.twig");
        } catch (Twig_Error_Loader $e) {
            $e->setTemplateFile($this->getTemplateName());
            $e->setTemplateLine(1);

            throw $e;
        }

        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FakeUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_fos_user_content($context, array $blocks = array())
    {
        // line 3
        echo "    <header class=\"gallery-header\">
            <h1 class=\"entry-title-font\">Templates Gallery</h1>
            ";
        // line 6
        echo "            <p class=\"meta-info-font\">Your device is ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["device"]) ? $context["device"] : $this->getContext($context, "device")), "type", array()), "html", null, true);
        echo "</p>
            <p></p>
    </header>

    <section class=\"gallery\">

        ";
        // line 12
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["data"]) ? $context["data"] : $this->getContext($context, "data")));
        foreach ($context['_seq'] as $context["key"] => $context["value"]) {
            // line 13
            echo "            <div class=\"wrapper\">
                <a href=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["value"], "href", array()), "html", null, true);
            echo "\">
                    <img class=\"thumbnail\" src=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["value"], "imgPath", array()), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["value"], "appName", array()), "html", null, true);
            echo "\">
                </a>
            </div><!--wrapper-->
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "    </section><!--works-->
";
    }

    public function getTemplateName()
    {
        return "FakeTemplateBundle:Default:template.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 19,  64 => 15,  60 => 14,  57 => 13,  53 => 12,  43 => 6,  39 => 3,  36 => 2,  11 => 1,);
    }
}

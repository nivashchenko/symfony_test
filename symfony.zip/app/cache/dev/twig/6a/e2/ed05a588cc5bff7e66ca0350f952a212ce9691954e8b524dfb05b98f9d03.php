<?php

/* FakeTemplateBundle:Default:index.html.twig */
class __TwigTemplate_6ae2ed05a588cc5bff7e66ca0350f952a212ce9691954e8b524dfb05b98f9d03 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        try {
            $this->parent = $this->env->loadTemplate("FakeUserBundle::base.html.twig");
        } catch (Twig_Error_Loader $e) {
            $e->setTemplateFile($this->getTemplateName());
            $e->setTemplateLine(1);

            throw $e;
        }

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FakeUserBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    <header class=\"site-header\">
\t\t\t<h1 class=\"title title-font\">Fake Apps</h1>
\t\t\t<p class=\"tagline tagline-font\">
\t\t\t\tCreate and download templates of popular applications.
\t\t\t</p>
\t\t</header>

\t\t<div class=\"sparator\"></div>
\t\t<section class=\"works-hex\">

\t\t\t<a href=\"#\" class=\"category category-1\">
\t\t\t\t<div class=\"wrapper\"><!--A helper to keep the hexagon's aspect ratio-->
\t\t\t\t\t<div class=\"hexagon\">
\t\t\t\t\t\t<div class=\"hexagon-in1\">
\t\t\t\t\t\t\t<div class=\"hexagon-in2\">
\t\t\t\t\t\t\t\t<img class=\"thumbnail\" src=\"img/01_1.jpg\" alt=\"thumbnail\">
\t\t\t\t\t\t\t</div><!--hexagon-in2-->
\t\t\t\t\t\t</div><!--hexagon-in1-->
\t\t\t\t\t</div><!--hexagon-->
\t\t\t\t</div><!--wrapper-->
\t\t\t\t<div class=\"category-name\"><h2 class=\"works-font\">iPhone</h2></div>
\t\t\t</a><!--category-1-->

\t\t\t<a href=\"#\"  class=\"category category-2\">
\t\t\t\t<div class=\"wrapper\">
\t\t\t\t\t<div class=\"hexagon\">
\t\t\t\t\t\t<div class=\"hexagon-in1\">
\t\t\t\t\t\t\t<div class=\"hexagon-in2\">
\t\t\t\t\t\t\t\t<img class=\"thumbnail\" src=\"img/02_1.jpg\" alt=\"thumbnail\">
\t\t\t\t\t\t\t</div><!--hexagon-in2-->
\t\t\t\t\t\t</div><!--hexagon-in1-->
\t\t\t\t\t</div><!--hexagon-->
\t\t\t\t</div><!--wrapper-->
\t\t\t\t<div class=\"category-name\"><h2 class=\"works-font\">iPad</h2></div>
\t\t\t</a><!--category-2-->

\t\t\t<a href=\"#\"  class=\"category category-3\">
\t\t\t\t<div class=\"wrapper\">
\t\t\t\t\t<div class=\"hexagon\">
\t\t\t\t\t\t<div class=\"hexagon-in1\">
\t\t\t\t\t\t\t<div class=\"hexagon-in2\">
\t\t\t\t\t\t\t\t<img class=\"thumbnail\" src=\"img/03_1.png\" alt=\"thumbnail\">
\t\t\t\t\t\t\t</div><!--hexagon-in2-->
\t\t\t\t\t\t</div><!--hexagon-in1-->
\t\t\t\t\t</div><!--hexagon-->
\t\t\t\t</div><!--wrapper-->
\t\t\t\t<div class=\"category-name\"><h2 class=\"works-font\">PC and LapTop</h2></div>
\t\t\t</a><!--category-3-->

\t\t</section><!--works-->
\t\t<div class=\"sparator\"></div>
";
    }

    public function getTemplateName()
    {
        return "FakeTemplateBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 4,  36 => 3,  11 => 1,);
    }
}

<?php

/* FakeUserBundle:User:resetting.email.html.twig */
class __TwigTemplate_34d4cccf8c351d3c0d1a5bc4c735a4eaeed613f1d3ca5cf2e63ba93b1489ad83 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
";
        // line 3
        $this->displayBlock('subject', $context, $blocks);
        // line 6
        echo "
";
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 17
        echo "
";
        // line 18
        $this->displayBlock('body_html', $context, $blocks);
    }

    // line 3
    public function block_subject($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("mail.title_reset", array(), "FakeUserBundle"), "html", null, true);
        echo "
";
    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        // line 9
        echo $this->env->getExtension('translator')->trans("mail.hello", array(), "FakeUserBundle");
        echo " ";
        echo $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "username", array());
        echo " !

";
        // line 11
        echo $this->env->getExtension('translator')->trans("mail.content", array(), "FakeUserBundle");
        echo " ";
        echo (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : null);
        echo "

";
        // line 13
        echo $this->env->getExtension('translator')->trans("mail.greetings", array(), "FakeUserBundle");
        echo ",
";
        // line 14
        echo $this->env->getExtension('translator')->trans("mail.the", array(), "FakeUserBundle");
        echo " Fake Team
";
    }

    // line 18
    public function block_body_html($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "FakeUserBundle:User:resetting.email.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  76 => 18,  70 => 14,  66 => 13,  59 => 11,  52 => 9,  49 => 7,  42 => 4,  39 => 3,  35 => 18,  32 => 17,  30 => 7,  27 => 6,  25 => 3,  22 => 2,);
    }
}

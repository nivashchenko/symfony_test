<?php

namespace Fake\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FakeAdminBundle extends Bundle
{
}

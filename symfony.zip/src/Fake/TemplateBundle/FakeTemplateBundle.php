<?php

namespace Fake\TemplateBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FakeTemplateBundle extends Bundle
{
}

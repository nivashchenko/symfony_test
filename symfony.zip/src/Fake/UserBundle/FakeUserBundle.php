<?php

namespace Fake\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FakeUserBundle extends Bundle
{
}
